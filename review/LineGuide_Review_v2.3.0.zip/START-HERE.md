# LineGuide 2.3.0 review bundle

Open revisions/v2.3.0/artifact/LineGuide_Proposal_v2.3.0.pdf or the editable PPTX beside it. Complete slide text/notes and standalone architecture PNGs/Mermaid are inside that same candidate directory. Its SHA256SUMS verifies every candidate file except itself. CURRENT.json identifies the sole current candidate. Earlier versions are omitted from this bundle.

This is a hypothetical course proposal with labelled scenario facts, assumptions and synthetic illustrations. Evaluation describes future implementation work. No classroom submission is claimed.
